<!--
<div class="guestbookTop">
<a href="postform.php">Write</a> to a guestbook<br><br>
</div>
-->
<?php
 $fileName = file ("shoutbox.txt");
 $displayLimit = 10;
 
 $rows = count ($fileName);
 $row = isset($_GET['row']) ? $_GET['row'] : 0;
 
 if ($rows > $displayLimit)
 {
	// Display Shouts
    for ($i = $row; $i < ($row + $displayLimit); $i++)
	{
		if ($i<$rows)
		echo $fileName [$i];
	}
	//Nav:
 	print ("<table class=\"shoutBoxNavigation\"><tr><td width=\"50%\">");
 	if ($row > 0){
		echo "<div class=\"nextPage\"><< <a href=\"readbook.php?row=" . ($row - $displayLimit) . "\">Next $displayLimit</a></div>";
	}
	print ("</td><td width=\"50%\">");
 	if ( ($rows - $row) > $displayLimit){
		echo "<div class=\"previousPage\"><a href=\"readbook.php?row=" . ($row + $displayLimit) . "\">Previous $displayLimit</a> >></div>";
	}
	print ("</td></tr></table>");


 }
 else
 {
  	for ($i=0; $i < $rows; $i++)
  	{
  		echo $fileName [$i];
  	}
 }
  
?>
<!---
<div class="guestbookUp">
<br><br><br><br>	
<a href="postform.php">Write</a> to a guestbook
</div>
-->