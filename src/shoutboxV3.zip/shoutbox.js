/***
// Modified by Brian Khuu to be easily usable anywhere with PHP, and to simplify the coding to take advantage of HTML5 features.
***/

/***************************/
//@Author: Adrian "yEnS" Mato Gondelle & Ivan Guardado Castro
//@website: www.yensdesign.com
//@email: yensamg@gmail.com
//@license: Feel free to use it, but keep this credits please!					
/***************************/

$(document).ready(function(){
	// Config
	var postURL = "/shoutbox/addbook.php" ; 
	var readURL = "/shoutbox/readbook.php" ;
	//global vars
	var inputUser = $("#nick");
	var inputMessage = $("#message");
	var messageList = $(".content");
	var prevMsgDivs = null;	// Global var for Speech Synth function
	
	//functions
	// Shoutbox Functions
	function updateShoutbox(){
		//just for the fade effect
		//send the post to shoutbox.php
		$.ajax({
			type: "POST", url: readURL, data: "",
			complete: function(data){
				messageList.html(data.responseText);
				messageList.fadeIn(2000);
			}
		});
	}
	//check if all fields are filled
	function checkForm(){
		if(inputUser.val() && inputMessage.val())
			if((inputUser.val() == "Name") || (inputMessage.val() == "Message"))
				return false;
			else
				return true;
		else
			return false;
	}
	
	//Load for the first time the shoutbox data
	updateShoutbox();
	setInterval(function(){updateShoutbox();}, 10000);

	//on submit event
	$("#form").submit(function(){
		if(checkForm()){
			var nick = inputUser.val();
			var message = inputMessage.val();
			//we deactivate submit button while sending
			$("#send").attr({ disabled:true, value:"Sending..." });
			$("#send").blur();
			//send the post to shoutbox.php
			$.ajax({
				type: "POST", url: postURL, data: "name=" + nick + "&message=" + message,
				complete: function(data){
					messageList.html(data.responseText);
					updateShoutbox();
					//reactivate the send button
					$("#send").attr({ disabled:false, value:"Send" });
                    $("#message").attr({ disabled:false, value:"" });
                    $("#message").focus();
				}
			 });
			 //Clear Message Box
			 inputMessage.val("");
		}
		else alert("Please fill all fields!");
		//we prevent the refresh of the page after submitting the form
		return false;
	});
});